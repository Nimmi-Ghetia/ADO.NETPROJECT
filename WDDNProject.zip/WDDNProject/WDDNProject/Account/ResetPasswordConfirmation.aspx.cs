﻿using System.Web.UI;

namespace WDDNProject.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}