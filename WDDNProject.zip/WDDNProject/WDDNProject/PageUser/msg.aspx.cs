﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WDDNProject
{
    public partial class msg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int type = Int32.Parse(Session["type"] + "");
            if (Session["uid"] == null || (type != 1 && type != 2))
            {
                Label3.Text = (Session["uid"] == null) + "     "+ (type != 1)+"    "+(type != 2)+ "    "+ (Session["uid"] == null || type != 1 || type != 2);
               // Response.Redirect("~/PageCommon/LoginPage.aspx");

            }
            
                Label1.Text = Session["uid"].ToString();
            Label2.Text = Int32.Parse(Session["type"].ToString())+"";
        }
    }
}