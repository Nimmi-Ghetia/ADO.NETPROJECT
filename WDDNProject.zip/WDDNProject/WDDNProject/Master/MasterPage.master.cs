﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Master_MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
      //  if (Session["uid"] != null&&Session["type"]!=null)
        //{
            
                //HyperLink hyp=(HyperLink)HeadLoginView.FindControl("HyperLink1");
            /*LoginName lg = HeadLoginView.FindControl("HeadLoginName") as LoginName;
            if(lg!=null)
            {
                lg.
            } */              

/*            int tp = Int32.Parse(Session["type"] + "");
            if (tp==1)
          {
                Response.Redirect("~/PageAdmin/Admin.aspx");
              //hyp.NavigateUrl = "~/PageAdmin/Admin.aspx";
          }
          else if(tp==2)
          {
                Response.Redirect("~/PageUser/MyProfile.aspx");
              //hyp.NavigateUrl = "~/PageUser/MyProfile.aspx";
          }
        */ 
        //}
       
           
    }
}
